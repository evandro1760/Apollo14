/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/joelf/Desktop/aulas/Microprocessados/contador/decoder.vhd";
extern char *IEEE_P_3620187407;



static void work_a_2263464102_3212880686_p_0(char *t0)
{
    char t5[16];
    char t20[16];
    char t34[16];
    char t48[16];
    char t62[16];
    char t76[16];
    char t90[16];
    char t104[16];
    char t118[16];
    char *t1;
    char *t2;
    char *t3;
    char *t6;
    char *t7;
    int t8;
    unsigned int t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t21;
    char *t22;
    int t23;
    unsigned char t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    char *t35;
    char *t36;
    int t37;
    unsigned char t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    char *t45;
    char *t46;
    char *t49;
    char *t50;
    int t51;
    unsigned char t52;
    char *t53;
    char *t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    char *t59;
    char *t60;
    char *t63;
    char *t64;
    int t65;
    unsigned char t66;
    char *t67;
    char *t68;
    char *t69;
    char *t70;
    char *t71;
    char *t72;
    char *t73;
    char *t74;
    char *t77;
    char *t78;
    int t79;
    unsigned char t80;
    char *t81;
    char *t82;
    char *t83;
    char *t84;
    char *t85;
    char *t86;
    char *t87;
    char *t88;
    char *t91;
    char *t92;
    int t93;
    unsigned char t94;
    char *t95;
    char *t96;
    char *t97;
    char *t98;
    char *t99;
    char *t100;
    char *t101;
    char *t102;
    char *t105;
    char *t106;
    int t107;
    unsigned char t108;
    char *t109;
    char *t110;
    char *t111;
    char *t112;
    char *t113;
    char *t114;
    char *t115;
    char *t116;
    char *t119;
    char *t120;
    int t121;
    unsigned char t122;
    char *t123;
    char *t124;
    char *t125;
    char *t126;
    char *t127;
    char *t128;
    char *t129;
    char *t130;
    char *t131;
    char *t132;
    char *t133;
    char *t134;

LAB0:    xsi_set_current_line(43, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6316U);
    t3 = (t0 + 6590);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 3;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (3 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t10 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t2, t1, t3, t5);
    if (t10 != 0)
        goto LAB3;

LAB4:    t16 = (t0 + 1032U);
    t17 = *((char **)t16);
    t16 = (t0 + 6316U);
    t18 = (t0 + 6594);
    t21 = (t20 + 0U);
    t22 = (t21 + 0U);
    *((int *)t22) = 0;
    t22 = (t21 + 4U);
    *((int *)t22) = 3;
    t22 = (t21 + 8U);
    *((int *)t22) = 1;
    t23 = (3 - 0);
    t9 = (t23 * 1);
    t9 = (t9 + 1);
    t22 = (t21 + 12U);
    *((unsigned int *)t22) = t9;
    t24 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t17, t16, t18, t20);
    if (t24 != 0)
        goto LAB5;

LAB6:    t30 = (t0 + 1032U);
    t31 = *((char **)t30);
    t30 = (t0 + 6316U);
    t32 = (t0 + 6598);
    t35 = (t34 + 0U);
    t36 = (t35 + 0U);
    *((int *)t36) = 0;
    t36 = (t35 + 4U);
    *((int *)t36) = 3;
    t36 = (t35 + 8U);
    *((int *)t36) = 1;
    t37 = (3 - 0);
    t9 = (t37 * 1);
    t9 = (t9 + 1);
    t36 = (t35 + 12U);
    *((unsigned int *)t36) = t9;
    t38 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t31, t30, t32, t34);
    if (t38 != 0)
        goto LAB7;

LAB8:    t44 = (t0 + 1032U);
    t45 = *((char **)t44);
    t44 = (t0 + 6316U);
    t46 = (t0 + 6602);
    t49 = (t48 + 0U);
    t50 = (t49 + 0U);
    *((int *)t50) = 0;
    t50 = (t49 + 4U);
    *((int *)t50) = 3;
    t50 = (t49 + 8U);
    *((int *)t50) = 1;
    t51 = (3 - 0);
    t9 = (t51 * 1);
    t9 = (t9 + 1);
    t50 = (t49 + 12U);
    *((unsigned int *)t50) = t9;
    t52 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t45, t44, t46, t48);
    if (t52 != 0)
        goto LAB9;

LAB10:    t58 = (t0 + 1032U);
    t59 = *((char **)t58);
    t58 = (t0 + 6316U);
    t60 = (t0 + 6606);
    t63 = (t62 + 0U);
    t64 = (t63 + 0U);
    *((int *)t64) = 0;
    t64 = (t63 + 4U);
    *((int *)t64) = 3;
    t64 = (t63 + 8U);
    *((int *)t64) = 1;
    t65 = (3 - 0);
    t9 = (t65 * 1);
    t9 = (t9 + 1);
    t64 = (t63 + 12U);
    *((unsigned int *)t64) = t9;
    t66 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t59, t58, t60, t62);
    if (t66 != 0)
        goto LAB11;

LAB12:    t72 = (t0 + 1032U);
    t73 = *((char **)t72);
    t72 = (t0 + 6316U);
    t74 = (t0 + 6610);
    t77 = (t76 + 0U);
    t78 = (t77 + 0U);
    *((int *)t78) = 0;
    t78 = (t77 + 4U);
    *((int *)t78) = 3;
    t78 = (t77 + 8U);
    *((int *)t78) = 1;
    t79 = (3 - 0);
    t9 = (t79 * 1);
    t9 = (t9 + 1);
    t78 = (t77 + 12U);
    *((unsigned int *)t78) = t9;
    t80 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t73, t72, t74, t76);
    if (t80 != 0)
        goto LAB13;

LAB14:    t86 = (t0 + 1032U);
    t87 = *((char **)t86);
    t86 = (t0 + 6316U);
    t88 = (t0 + 6614);
    t91 = (t90 + 0U);
    t92 = (t91 + 0U);
    *((int *)t92) = 0;
    t92 = (t91 + 4U);
    *((int *)t92) = 3;
    t92 = (t91 + 8U);
    *((int *)t92) = 1;
    t93 = (3 - 0);
    t9 = (t93 * 1);
    t9 = (t9 + 1);
    t92 = (t91 + 12U);
    *((unsigned int *)t92) = t9;
    t94 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t87, t86, t88, t90);
    if (t94 != 0)
        goto LAB15;

LAB16:    t100 = (t0 + 1032U);
    t101 = *((char **)t100);
    t100 = (t0 + 6316U);
    t102 = (t0 + 6618);
    t105 = (t104 + 0U);
    t106 = (t105 + 0U);
    *((int *)t106) = 0;
    t106 = (t105 + 4U);
    *((int *)t106) = 3;
    t106 = (t105 + 8U);
    *((int *)t106) = 1;
    t107 = (3 - 0);
    t9 = (t107 * 1);
    t9 = (t9 + 1);
    t106 = (t105 + 12U);
    *((unsigned int *)t106) = t9;
    t108 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t101, t100, t102, t104);
    if (t108 != 0)
        goto LAB17;

LAB18:    t114 = (t0 + 1032U);
    t115 = *((char **)t114);
    t114 = (t0 + 6316U);
    t116 = (t0 + 6622);
    t119 = (t118 + 0U);
    t120 = (t119 + 0U);
    *((int *)t120) = 0;
    t120 = (t119 + 4U);
    *((int *)t120) = 3;
    t120 = (t119 + 8U);
    *((int *)t120) = 1;
    t121 = (3 - 0);
    t9 = (t121 * 1);
    t9 = (t9 + 1);
    t120 = (t119 + 12U);
    *((unsigned int *)t120) = t9;
    t122 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t115, t114, t116, t118);
    if (t122 != 0)
        goto LAB19;

LAB20:
LAB21:    t128 = (t0 + 2568U);
    t129 = *((char **)t128);
    t128 = (t0 + 3952);
    t130 = (t128 + 56U);
    t131 = *((char **)t130);
    t132 = (t131 + 56U);
    t133 = *((char **)t132);
    memcpy(t133, t129, 7U);
    xsi_driver_first_trans_fast_port(t128);

LAB2:    t134 = (t0 + 3872);
    *((int *)t134) = 1;

LAB1:    return;
LAB3:    t7 = (t0 + 1488U);
    t11 = *((char **)t7);
    t7 = (t0 + 3952);
    t12 = (t7 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t11, 7U);
    xsi_driver_first_trans_fast_port(t7);
    goto LAB2;

LAB5:    t22 = (t0 + 1608U);
    t25 = *((char **)t22);
    t22 = (t0 + 3952);
    t26 = (t22 + 56U);
    t27 = *((char **)t26);
    t28 = (t27 + 56U);
    t29 = *((char **)t28);
    memcpy(t29, t25, 7U);
    xsi_driver_first_trans_fast_port(t22);
    goto LAB2;

LAB7:    t36 = (t0 + 1728U);
    t39 = *((char **)t36);
    t36 = (t0 + 3952);
    t40 = (t36 + 56U);
    t41 = *((char **)t40);
    t42 = (t41 + 56U);
    t43 = *((char **)t42);
    memcpy(t43, t39, 7U);
    xsi_driver_first_trans_fast_port(t36);
    goto LAB2;

LAB9:    t50 = (t0 + 1848U);
    t53 = *((char **)t50);
    t50 = (t0 + 3952);
    t54 = (t50 + 56U);
    t55 = *((char **)t54);
    t56 = (t55 + 56U);
    t57 = *((char **)t56);
    memcpy(t57, t53, 7U);
    xsi_driver_first_trans_fast_port(t50);
    goto LAB2;

LAB11:    t64 = (t0 + 1968U);
    t67 = *((char **)t64);
    t64 = (t0 + 3952);
    t68 = (t64 + 56U);
    t69 = *((char **)t68);
    t70 = (t69 + 56U);
    t71 = *((char **)t70);
    memcpy(t71, t67, 7U);
    xsi_driver_first_trans_fast_port(t64);
    goto LAB2;

LAB13:    t78 = (t0 + 2088U);
    t81 = *((char **)t78);
    t78 = (t0 + 3952);
    t82 = (t78 + 56U);
    t83 = *((char **)t82);
    t84 = (t83 + 56U);
    t85 = *((char **)t84);
    memcpy(t85, t81, 7U);
    xsi_driver_first_trans_fast_port(t78);
    goto LAB2;

LAB15:    t92 = (t0 + 2208U);
    t95 = *((char **)t92);
    t92 = (t0 + 3952);
    t96 = (t92 + 56U);
    t97 = *((char **)t96);
    t98 = (t97 + 56U);
    t99 = *((char **)t98);
    memcpy(t99, t95, 7U);
    xsi_driver_first_trans_fast_port(t92);
    goto LAB2;

LAB17:    t106 = (t0 + 2328U);
    t109 = *((char **)t106);
    t106 = (t0 + 3952);
    t110 = (t106 + 56U);
    t111 = *((char **)t110);
    t112 = (t111 + 56U);
    t113 = *((char **)t112);
    memcpy(t113, t109, 7U);
    xsi_driver_first_trans_fast_port(t106);
    goto LAB2;

LAB19:    t120 = (t0 + 2448U);
    t123 = *((char **)t120);
    t120 = (t0 + 3952);
    t124 = (t120 + 56U);
    t125 = *((char **)t124);
    t126 = (t125 + 56U);
    t127 = *((char **)t126);
    memcpy(t127, t123, 7U);
    xsi_driver_first_trans_fast_port(t120);
    goto LAB2;

LAB22:    goto LAB2;

}


extern void work_a_2263464102_3212880686_init()
{
	static char *pe[] = {(void *)work_a_2263464102_3212880686_p_0};
	xsi_register_didat("work_a_2263464102_3212880686", "isim/test_mostrador_isim_beh.exe.sim/work/a_2263464102_3212880686.didat");
	xsi_register_executes(pe);
}
